package com.sapient.feecalculator.entity;

import java.time.LocalDate;

import com.sapient.feecalculator.constant.SapeFeeCalcConstants.*;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class TransactionReport {

	private String clientId;
	private TransactionType transactionType;
	private LocalDate transactionDate;
	private TransactionPriority priority;
	private double processingFee;
	
}
