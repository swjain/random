package com.sapient.feecalculator.constant;

public class SapeFeeCalcConstants {
	
	public static enum TransactionPriority { Y, N }
	public static enum TransactionType { BUY, SELL, DEPOSIT, WITHDRAW }

	public static final String TRANSACTION_READER = "transactionReader";
	public static final String TRANSACTION_PROCESSOR = "transactionProcessor";
	public static final String BATCH_STEP = "step";
	
	private SapeFeeCalcConstants() {}
	
}
