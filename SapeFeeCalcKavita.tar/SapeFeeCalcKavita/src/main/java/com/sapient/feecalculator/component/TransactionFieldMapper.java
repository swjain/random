package com.sapient.feecalculator.component;

import java.time.LocalDate;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sapient.feecalculator.constant.SapeFeeCalcConstants.TransactionPriority;
import com.sapient.feecalculator.constant.SapeFeeCalcConstants.TransactionType;
import com.sapient.feecalculator.entity.Transaction;

@Component
public class TransactionFieldMapper implements FieldSetMapper<Transaction> {
	
	private ObjectMapper mapper = new ObjectMapper();

	@Override
	public Transaction mapFieldSet(FieldSet fieldSet) {
		try {
			return Transaction.builder()
				.externalTransactionId(fieldSet.readString("External Transaction Id"))
				.clientId(fieldSet.readString("Client Id"))
				.securityId(fieldSet.readString("Security Id"))
				.transactionType(mapper.readValue(fieldSet.readString("Transaction Type"), TransactionType.class))
				.transactionDate(mapper.readValue(fieldSet.readString("Transaction Date"), LocalDate.class))
				.marketValue(fieldSet.readDouble("Market Value"))
				.priority(mapper.readValue(fieldSet.readString("Priority Flag"), TransactionPriority.class))
				.build();
		} catch (JsonProcessingException e) {
			throw new RuntimeException(e);
		}
	}

}
