package com.sapient.feecalculator.component;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.sapient.feecalculator.entity.Transaction;
import com.sapient.feecalculator.entity.TransactionReport;
import com.sapient.feecalculator.strategy.IProcessingFeeStrategy;

public class TransactionProcessor implements ItemProcessor<Transaction, TransactionReport> {

	@Autowired
	private IProcessingFeeStrategy processingFeeStrategy;
	
    @Override
    public TransactionReport process(Transaction transaction) throws Exception {
    	return TransactionReport.builder()
    			.clientId(transaction.getClientId())
    			.transactionType(transaction.getTransactionType())
    			.transactionDate(transaction.getTransactionDate())
    			.priority(transaction.getPriority())
    			.processingFee(computeProcessingFee(transaction))
    			.build();
    }

	private double computeProcessingFee(Transaction transaction) {
		System.out.println(transaction);
		return processingFeeStrategy.execute(transaction);
	}
    
}