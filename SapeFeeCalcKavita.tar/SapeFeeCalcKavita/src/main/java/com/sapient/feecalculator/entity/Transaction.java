package com.sapient.feecalculator.entity;

import java.time.LocalDate;

import com.sapient.feecalculator.constant.SapeFeeCalcConstants.*;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Transaction {
	
	private String externalTransactionId;
	private String clientId;
	private String securityId;
	private TransactionType transactionType;
	private LocalDate transactionDate;
	private double marketValue;
	private TransactionPriority priority;

}