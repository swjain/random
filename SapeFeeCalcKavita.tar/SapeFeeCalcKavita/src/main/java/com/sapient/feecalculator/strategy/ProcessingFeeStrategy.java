package com.sapient.feecalculator.strategy;

import org.springframework.stereotype.Component;

import com.sapient.feecalculator.entity.Transaction;

@Component
public class ProcessingFeeStrategy implements IProcessingFeeStrategy {

	@Override
	public double execute(Transaction transaction) {
		// TODO Auto-generated method stub
		return 0;
	}

	
}
