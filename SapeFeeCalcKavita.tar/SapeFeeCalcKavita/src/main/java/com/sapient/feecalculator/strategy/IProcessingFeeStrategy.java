package com.sapient.feecalculator.strategy;

import com.sapient.feecalculator.entity.Transaction;

public interface IProcessingFeeStrategy {
	
	public double execute(Transaction transaction);

}
