package com.sapient.feecalculator.config;

import static com.sapient.feecalculator.constant.SapeFeeCalcConstants.BATCH_STEP;
import static com.sapient.feecalculator.constant.SapeFeeCalcConstants.TRANSACTION_PROCESSOR;
import static com.sapient.feecalculator.constant.SapeFeeCalcConstants.TRANSACTION_READER;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.DefaultBatchConfigurer;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.builder.FlatFileItemWriterBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import com.sapient.feecalculator.component.JobListener;
import com.sapient.feecalculator.component.TransactionFieldMapper;
import com.sapient.feecalculator.component.TransactionProcessor;
import com.sapient.feecalculator.entity.Transaction;
import com.sapient.feecalculator.entity.TransactionReport;

@Configuration
public class SapeFeeCalcConfig extends DefaultBatchConfigurer {

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Autowired
	private TransactionFieldMapper fieldMapper;

	@Override
	public void setDataSource(DataSource dataSource) {
		// initialize will use a Map based JobRepository (instead of database)
	}

	@Value("${input.csv.headers}")
	private String[] inputHeaders;

	@Value("${output.csv.headers}")
	private String[] outputHeaders;

	private Resource outputResource = new FileSystemResource("output/outputData.csv");

	@Bean
	public FlatFileItemReader<Transaction> reader() {
		return new FlatFileItemReaderBuilder<Transaction>()
				.name(TRANSACTION_READER)
				.resource(new ClassPathResource("csv/input.csv"))
				.linesToSkip(1)
				.delimited()
				.names(inputHeaders)
				.lineMapper(lineMapper())
				.fieldSetMapper(new BeanWrapperFieldSetMapper<Transaction>() {{
					setTargetType(Transaction.class);
				}}).build();
	}

	@Bean
	public LineMapper<Transaction> lineMapper() {
		final DefaultLineMapper<Transaction> defaultLineMapper = new DefaultLineMapper<>();
		final DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
		lineTokenizer.setDelimiter(",");
		lineTokenizer.setStrict(false);
		lineTokenizer.setNames(inputHeaders);
		defaultLineMapper.setLineTokenizer(lineTokenizer);
		defaultLineMapper.setFieldSetMapper(fieldMapper);
		return defaultLineMapper;
	}

	@Bean
	public TransactionProcessor processor() {
		return new TransactionProcessor();
	}

	@Bean
	public FlatFileItemWriter<TransactionReport> writer(final DataSource dataSource) {
		return new FlatFileItemWriterBuilder<TransactionReport>()
				.resource(outputResource)
				.append(true)
				.lineAggregator(new DelimitedLineAggregator<TransactionReport>() {{
					setDelimiter(",");
					setFieldExtractor(new BeanWrapperFieldExtractor<TransactionReport>() {{
						setNames(outputHeaders);
					}});
				}})
				.build();
	}

	@Bean
	public Step step(FlatFileItemWriter<Transaction> writer) {
		return stepBuilderFactory.get(BATCH_STEP)
				.<Transaction, TransactionReport> chunk(5)
				.reader(reader())
				.processor(processor())
				.writer(writer())
				.build();
	}

	@Bean
	public Job job(JobListener listener, Step step) {
		return jobBuilderFactory.get(TRANSACTION_PROCESSOR)
				.incrementer(new RunIdIncrementer())
				.listener(listener)
				.flow(step)
				.end()
				.build();
	}

}

