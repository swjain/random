package com.sapient.feecalculator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SapFeeCalcApplicationTests {

	@Test
	void shouldComputeFeeForIntradayTransactions() {
		
	}

}
